# -*- coding: utf-8 -*-
"""
SYS-601: Example Scripts for Chi-squared Statistical Tests

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

# import scipy.stats library and refer to it as `stats`
import scipy.stats as stats

# import numpy library and refer to it as `np`
import numpy as np

#%% Computing Ranks Example

# list the raw samples in text format
samples = np.array(['Poor', 'Poor', 'Good', 'Good', 'Good', 'Good', 'Excellent'])

# convert the samples to numeric format
samples = np.array([0, 0, 1, 1, 1, 1, 2])

# compute the sample ranks
ranks = stats.rankdata(samples)

print (ranks)

#%% Example: Butcher Prices: Spearman Rank Correlation

lamb =   np.array([77.91, 82.00, 89.20, 74.37, 66.42, 80.10, 69.78, 72.09, 92.14, 96.31])
heifer = np.array([65.46, 64.18, 65.66, 59.23, 65.68, 69.55, 67.81, 67.39, 82.06, 84.40])

r_s, p = stats.spearmanr(lamb, heifer)

print ('r_s = {:.3f}'.format(r_s))

#%% Wage Example: Mann-Whitney U Test

# list the healthcare worker wages in an array
health_samples = np.array([20.10, 19.80, 22.36, 18.75, 21.90, 22.96, 20.75])

# list the education worker wages in an array
education_samples = np.array([26.19, 23.88, 25.50, 21.64, 24.85, 25.30, 24.12, 23.45])

# perform a one-sided mann-whitney u test with alternative: health < education
U, p = stats.mannwhitneyu(health_samples, education_samples, alternative='less')

print 'U = {:.2f}, p = {:.4f}'.format(U, p)

#%% Healthcare Spending Example: Wilcoxon Matched Pairs Test

# list the pittsburgh family spending samples in an array
pittsburgh = np.array([1950, 1840, 2015, 1580, 1790, 1925])

# list the oakland family spending samples in an array
oakland = np.array([1760, 1870, 1810, 1660, 1340, 1765])

# perform a wilcoxon matched pairs test
T, p = stats.wilcoxon(pittsburgh, oakland)

print 'T = {:.2f}, p = {:.4f}'.format(T, p)

#%% Example: Patients per Doctor: Kruskal-Wallis Test

# list the patients for 2-partner firms
two_partners = np.array([13, 15, 20, 18, 23])

# list the patients for 2-partner firms
three_partners = np.array([24, 16, 19, 22, 25, 14, 17])

# list the patients for hmo firms
hmo = np.array([26, 22, 31, 27, 28, 33])

# perform a kruskal-wallis test to see if there is difference among firm types
H, p = stats.kruskal(two_partners, three_partners, hmo)

print 'H = {:.2f}, p = {:.4f}'.format(H, p)

#%% Example: Damaged Products: Friedman Test

# list the number of damaged prodcuts from each supplier by day
supplier_1 = np.array([62, 63, 61, 62, 64])
supplier_2 = np.array([63, 61, 62, 60, 63])
supplier_3 = np.array([57, 59, 56, 57, 58])
supplier_4 = np.array([61, 65, 63, 64, 66])

# perform a friedman test to see if there is a difference among suppliers
Q, p = stats.friedmanchisquare(supplier_1, supplier_2, supplier_3, supplier_4)

print 'Q = {:.2f}, p = {:.4f}'.format(Q, p)
# -*- coding: utf-8 -*-
"""
SYS-601: Example Scripts for Chi-squared Statistical Tests

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

# import scipy.stats library and refer to it as `stats`
import scipy.stats as stats

# import numpy library and refer to it as `np`
import numpy as np

#%% Review Satisfaction Example: Chi-squared Test for Goodness-of-Fit

# this example compares reviews on the following scale to a distribution
labels = np.array(['Poor', 'Fair', 'Good', 'Excellent'])

# list the observed values as an array
observed = np.array([21, 109, 62, 15])

# list the probability mass function values as an array
pmf = np.array([0.08, 0.47, 0.34, 0.11])

# compute the expected values
expected = pmf * np.sum(observed)

# perform a chi-square goodness-of-fit test with c=0 delta-degrees of freedom
chi2, p = stats.chisquare(observed, expected, ddof=0)

print 'chi2 = {:.2f}, p = {:.2f}'.format(chi2, p)

#%% Dice Distribution Example -- Chi-squared Test for Goodness-of-Fit

# this example compares observed dice rolls for the following values
labels = np.array(['2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'])

# list the observed values as an array
observed = np.array([6, 18, 25, 25, 38, 59, 31, 22, 26, 13, 6])

# list the probability mass function values as an array
pmf = np.array([1./36, 2./36, 3./36, 4./36, 5./36, 6./36, 5./36, 4./36, 3./36, 2./36, 1./36])

# compute the expected values
expected = pmf * np.sum(observed)

# perform a chi-square goodness-of-fit test with c=0 delta-degrees of freedom
chi2, p = stats.chisquare(observed, expected, ddof=0)

print 'chi2 = {:.2f}, p = {:.2f}'.format(chi2, p)

#%% Dice Color Example -- Chi-squared Test for Independence

# this example compares observed dice rolls for the following values
labels = np.array(['2-3', '4-5', '6', '7', '8', '9-10', '11-12'])
observed = np.array([
            [10, 16, 15, 22,  9, 19, 3], #red
            [ 6, 23,  6, 19, 14, 16, 8], #blue
            [ 4,  5, 11, 11,  5,  2, 3], #green
            [ 4,  6,  6,  7,  3, 11, 5]  #purple
        ])

# perform a chi-square test for independence
chi2, p, dof, expected = stats.chi2_contingency(observed)

print 'chi2 = {:.2f}, p = {:.2f}'.format(chi2, p)
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.mlab as mlab

mu = 0.5
stdev = 0.0347
x = np.linspace(mu - 3*stdev, mu + 3*stdev, 100)
plt.plot(x,mlab.normpdf(x, mu, stdev))
axes = plt.gca()
axes.set_xlim([0,1])
plt.xlabel('Mean of x',fontsize = 14)
plt.ylabel('f(x)',fontsize = 14)
plt.show()
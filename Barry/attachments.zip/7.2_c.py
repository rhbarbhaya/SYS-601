import matplotlib.pyplot as plt
import numpy as np
import matplotlib.mlab as mlab

mu = 0
stdev = 1
x = np.linspace(mu - 3*stdev, mu + 3*stdev, 100)
plt.plot(x,mlab.normpdf(x, mu, stdev))
plt.axvline(x=1.96, ymax = 0.165, color='black')
plt.axvline(x=-1.96, ymax = 0.165, color='black')
plt.axvline(x=1.34, ymax = 0.413, color='red', linestyle='dashed')
plt.xlabel('Mean of x',fontsize = 14)
plt.ylabel('f(x)',fontsize = 14)
plt.show()
# -*- coding: utf-8 -*-
"""
Solution for SYS-601 HW-01

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# read the earthquakes into a data frame
df = pd.read_csv('earthquakes.csv')

# take the first four characters in the time column as the integer year
years = np.array([int(row[0:4]) for row in df['time']])
        
#%% 1.1(b)

# create a new figure with a size of 8 x 4 inches
plt.figure(figsize=(8,4))

# create a histogram using bin boundaries in the range between 2000 and 2018
# store the computed frequencies and bins for later use
frequencies, bins, patches = plt.hist(years, bins=range(2000,2018), color='r')
# set the x-axis ticks based on the bins
plt.xticks(bins)
# set the x-axis label
plt.xlabel('Year')
# set the y-axis label
plt.ylabel('Earthquake Frequency')
# save the figure as a pdf
plt.savefig('hw1-1b.pdf', bbox_inches='tight', dpi=300)

#%% 1.1(c)

# create a new figure
plt.figure()
# create a  histogram using bin boundaries between 1.5 and 4.75 (every 0.25)
plt.hist(df['mag'], bins=np.arange(1.5,4.75,.25), color='red')
# set the x-axis label
plt.xlabel('Magnitude')
# set the y-axis label
plt.ylabel('Earthquake Frequency')
# save the figure to file
plt.savefig('hw1-1c.pdf', bbox_inches='tight', dpi=300)

#%% 1.1(d)

# create a new figure
plt.figure()
# create a cumulative histogram
bins = np.arange(1.5,4.75,.25)
plt.plot(bins, [np.sum(df['mag'] <= x) for x in bins], '-or')
# set the x-axis label
plt.xlabel('Magnitude')
# set the y-axis label
plt.ylabel('Cumulative Earthquake Frequency')
# save the figure to file
plt.savefig('hw1-1d.pdf', bbox_inches='tight', dpi=300)

#%% 1.1(e)

# create a new figure
plt.figure()
# create a plot with the longitude and latitude data
plt.plot(df['longitude'], df['latitude'], 'or')
# set the labels for both axes
plt.xlabel('Longitude')
plt.ylabel('Latitude')
# save the figure to file
plt.savefig('hw1-1e.pdf', bbox_inches='tight', dpi=300)
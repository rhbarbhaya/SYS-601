# -*- coding: utf-8 -*-
"""
Solution for SYS-601 HW-02.2.

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

import numpy as np
import matplotlib.pyplot as plt

# record the data samples as a list
samples = [0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1]

print 'Sample mean: {:.2f}'.format(np.mean(samples))
print 'Sample standard devaition: {:.2f}'.format(np.std(samples, ddof=1))


# create a new figure
plt.hist(samples, bins=[0,1], color='r')
# set the ticks on the x-axis to only show 0 and 1
plt.xticks([0,1])
# set the x-axis label
plt.xlabel('Coin Toss Value')
# set the y-axis label
plt.ylabel('Frequency')
# save the figure to file
plt.savefig('hw2-2c.pdf', bbox_inches='tight', dpi=300)
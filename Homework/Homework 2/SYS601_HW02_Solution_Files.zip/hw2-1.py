# -*- coding: utf-8 -*-
"""
Solution for SYS-601 HW-02.1.

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# read the csv file into a data frame
df = pd.read_csv('origami.csv')
# create an array for the parsed team in each row
teams = np.array([row[0:1] for row in df['Paper ID']])
        
#%% 2.1(a)

print 'Mean boat duration: {:.1f} s'.format(
    np.mean(df['Duration (s)'][df['Type']=='Boat']))

print 'Median boat duration: {:.1f} s'.format(
    np.median(df['Duration (s)'][df['Type']=='Boat']))

print '5th percentile boat duration: {:.1f} s'.format(
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 5))

print '95th percentile boat duration: {:.1f} s'.format(
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 95))

print '1st quartile boat duration: {:.1f} s'.format(
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 25))

print '2nd quartile boat duration: {:.1f} s'.format(
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 50))

print '3rd quartile boat duration: {:.1f} s'.format(
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 75))

print 'IQR boat duration: {:.1f} s'.format(
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 75)-
    np.percentile(df['Duration (s)'][df['Type']=='Boat'], 25))

print 'Boat duration variance: {:.1f} s^2'.format(
    np.var(df['Duration (s)'][df['Type']=='Boat'], ddof=1)) # delta-degrees of freedom = 1

print 'Boat duration standard deviation: {:.1f} s'.format(
    np.std(df['Duration (s)'][df['Type']=='Boat'], ddof=1)) # delta-degrees of freedom = 1

# create a new figure
plt.figure()
# plot a histogram of the boat durations using red color
plt.hist(df['Duration (s)'][df['Type']=='Boat'], range(0,325,25), color='r')
# set the x-axis label
plt.xlabel('Duration (s)')
# set the y-axis label
plt.ylabel('Frequency')
# save the figure to file
plt.savefig('hw2-1a_vii.pdf', bbox_inches='tight', dpi=300)

#%% 2.1(b)

# create empty lists to store durations and labels for each qualifying team
team_durations = []
team_ids = []

# iterate over each team by name
for team in ['R','O','Y','G','B','V']:
    # get the boat durations for this team from the data frame by filtering
    durations = df['Duration (s)'][np.logical_and(df['Type']=='Boat', teams==team)]
    # if there are at least 5 boats
    if len(durations) >= 5:
        # store the durations as a list in the team_durations list
        team_durations.append([durations])
        # and store the team label in the team_ids list
        team_ids.append(team)
    
# create a new figure
plt.figure()
# create a box plot for each of the list of durations in the list
plt.boxplot(team_durations, positions=range(len(team_durations)))
# draw the team labels on the x-axis
plt.xticks(range(len(team_durations)), team_ids)
# set the x-axis label
plt.xlabel('Team')
# set the y-axis label
plt.ylabel('Boat Duration (s)')
# save the figure to file
plt.savefig('hw2-1b.pdf', bbox_inches='tight', dpi=300)
# -*- coding: utf-8 -*-
"""
SYS-601 HW4-1 Solution

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

# import the numpy package and refer to it as `np`
import numpy as np

# define the left dice rolls using a numpy array
Z_L = np.array([2, 4, 2, 2, 2, 6, 3, 4, 5, 1, 1, 1, 3, 1, 1, 
                4, 3, 4, 1, 6, 5, 6, 1, 1, 4, 3, 3, 4, 5, 4])

# define the right dice rolls using a numpy array
Z_R = np.array([3, 1, 3, 5, 5, 1, 2, 3, 6, 4, 6, 4, 3, 4, 6, 
                4, 3, 6, 1, 6, 1, 3, 5, 5, 6, 1, 6, 6, 1, 1])

# compute the derived random variable
# note: need 2. to prevent truncating/rounding off division
Z = np.ceil(Z_L/2.)-np.ceil(Z_R/2.) 

# define the range of possible values
z = np.arange(-2,2+1)

# count the number of instances of each value (uses a generator expression)
N_z = np.array([np.sum(Z == z_i) for z_i in np.arange(-2,2+1)])

# compute the empirical pmf
f_z = N_z/float(len(z))

print '{:>2s}{:>6s}'.format('z', 'f(z)')
for i in range(len(z)):
    print '{:2d}{:6.2f}'.format(z[i], f_z[i])
print
# compute the empirical cdf
F_z = np.cumsum(f_z)

print '{:>2s}{:>6s}'.format('z', 'F(z)')
for i in range(len(z)):
    print '{:2d}{:6.2f}'.format(z[i], F_z[i])
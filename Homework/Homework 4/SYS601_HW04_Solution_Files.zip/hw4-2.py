# -*- coding: utf-8 -*-
"""
SYS-601 HW4-2 Solution

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

# import the numpy package and refer to it as `np`
import numpy as np
# import the scipy.stats package and refer to it as `stats`
import scipy.stats as stats
# import the matplotlib.pyplot package and refer to it as `plt`
import matplotlib.pyplot as plt

# create an array of values between 0 and 10
y = np.arange(0,8)
# compute the PMF values using the poisson distribution with rate = 3.5
p_y = stats.poisson.pmf(y, 1.0)

# create a new figure
plt.figure()
# draw a bar plot using the PMF data
plt.bar(y, p_y, color='r')
# label the axes and save the figure
plt.xlabel('y')
plt.ylabel('p(y)')
plt.savefig('hw4-2b.png')

print 'p(0) = {:.2f}'.format(p_y[0])
print r'P(y >= 1) = {:.2f}'.format(1-p_y[0])
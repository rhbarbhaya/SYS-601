# -*- coding: utf-8 -*-
"""
SYS-601 HW4-3 Solution

@author: Paul T. Grogan, pgrogan@stevens.edu
"""

# import the numpy package and refer to it as `np`
import numpy as np
# import the scipy.stats package and refer to it as `stats`
import scipy.stats as stats
# import the matplotlib.pyplot package and refer to it as `plt`
import matplotlib.pyplot as plt

x = np.arange(0,52+1)
P_x = stats.binom.pmf(x, 52, 0.5)

plt.figure()
plt.bar(x, P_x, color='r')
plt.xlabel('Number of Toss Wins (x)')
plt.ylabel('p(x)')
plt.savefig('hw4-3b.png')

print 'P(X >= 35) = {:.3f}'.format(1-stats.binom.cdf(34, 52, 0.5))